<?php
/**
 * Plugin Name:       Hasbati Hijri Date Converter
 * Plugin URI:        https://hasbati.com/date-converter/
 * Description:       A lightweight Hijri to Gregorian and Gregorian to Hijri date converter widget based on the Umm al-Qura calendar. Use shortcode [hasbati_date_converter].
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.4
 * Author:            Hasbati
 * Author URI:        https://hasbati.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       hasbati-date-converter
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // منع الوصول المباشر
}

/**
 * تسجيل إعدادات الإضافة في لوحة التحكم (للتوافق مع Guideline #10 الخاص بالروابط)
 */
function hasbati_dc_register_settings() {
    register_setting(
        'hasbati_dc_settings_group',
        'hasbati_dc_show_credit',
        array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'no',
        )
    );
}
add_action( 'admin_init', 'hasbati_dc_register_settings' );

function hasbati_dc_admin_menu() {
    add_options_page(
        'إعدادات محول التاريخ - حاسبتي',
        'محول التاريخ (حاسبتي)',
        'manage_options',
        'hasbati-date-converter',
        'hasbati_dc_settings_page'
    );
}
add_action( 'admin_menu', 'hasbati_dc_admin_menu' );

function hasbati_dc_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $show_credit = get_option( 'hasbati_dc_show_credit', 'no' );
    ?>
    <div class="wrap" dir="rtl" style="font-family: Tahoma, Arial, sans-serif;">
        <h1>إعدادات أداة تحويل التاريخ الهجري والميلادي - حاسبتي</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'hasbati_dc_settings_group' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">شريط حقوق الأداة ومصدر التقويم</th>
                    <td>
                        <label>
                            <input type="checkbox" name="hasbati_dc_show_credit" value="yes" <?php checked( $show_credit, 'yes' ); ?> />
                            تفعيل الرابط المرجعي المصغر أسفل الأداة (يدعم استمرار التحديثات المجانية وتوثيق مصدر تقويم أم القرى).
                        </label>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'حفظ التغييرات' ); ?>
        </form>
        <hr>
        <h2>طريقة إضافة المحول في مقالاتك أو صفحاتك:</h2>
        <p>انسخ الكود القصير (Shortcode) التالي وضعه في أي مكان تريد ظهور الأداة فيه:</p>
        <p><code style="font-size: 16px; padding: 8px 12px; background: #e2e8f0; display: inline-block; direction: ltr;">[hasbati_date_converter credit="yes"]</code></p>
    </div>
    <?php
}

/**
 * بناء الشورت كود: [hasbati_date_converter credit="yes"]
 */
function hasbati_dc_shortcode_render( $atts ) {
    $atts = shortcode_atts(
        array(
            'credit' => get_option( 'hasbati_dc_show_credit', 'no' ),
        ),
        $atts,
        'hasbati_date_converter'
    );

    $uid = uniqid( 'hasbati_dc_' );

    ob_start();
    ?>
    <div id="<?php echo esc_attr( $uid ); ?>" class="hasbati-dc-box" dir="rtl" style="max-width: 520px; margin: 25px auto; padding: 22px; border: 1px solid #cbd5e1; border-radius: 12px; background: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); font-family: system-ui, -apple-system, sans-serif;">
        <h3 style="margin-top: 0; margin-bottom: 16px; font-size: 19px; color: #0f172a; text-align: center; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px;">
            محول التاريخ الهجري والميلادي
        </h3>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px; color: #334155;">نوع التحويل:</label>
            <select class="hasbati-dc-mode" style="width: 100%; padding: 10px; border: 1px solid #94a3b8; border-radius: 8px; font-size: 15px; background: #f8fafc; color: #0f172a;">
                <option value="g2h">من ميلادي إلى هجري</option>
                <option value="h2g">من هجري إلى ميلادي</option>
            </select>
        </div>

        <div style="display: flex; gap: 10px; margin-bottom: 18px;">
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px; font-size: 13px; color: #475569;">اليوم</label>
                <input type="number" class="hasbati-dc-day" min="1" max="31" value="<?php echo esc_attr( gmdate( 'd' ) ); ?>" style="width: 100%; padding: 9px; border: 1px solid #cbd5e1; border-radius: 8px; text-align: center; font-size: 15px; box-sizing: border-box;" />
            </div>
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px; font-size: 13px; color: #475569;">الشهر</label>
                <input type="number" class="hasbati-dc-month" min="1" max="12" value="<?php echo esc_attr( gmdate( 'm' ) ); ?>" style="width: 100%; padding: 9px; border: 1px solid #cbd5e1; border-radius: 8px; text-align: center; font-size: 15px; box-sizing: border-box;" />
            </div>
            <div style="flex: 1.4;">
                <label style="display: block; margin-bottom: 5px; font-size: 13px; color: #475569;">السنة</label>
                <input type="number" class="hasbati-dc-year" min="1300" max="2150" value="<?php echo esc_attr( gmdate( 'Y' ) ); ?>" style="width: 100%; padding: 9px; border: 1px solid #cbd5e1; border-radius: 8px; text-align: center; font-size: 15px; box-sizing: border-box;" />
            </div>
        </div>

        <button type="button" class="hasbati-dc-btn" style="width: 100%; padding: 12px; background: #0284c7; color: #ffffff; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; transition: background 0.2s;">
            تحويل التاريخ
        </button>

        <div class="hasbati-dc-result" style="display: none; margin-top: 18px; padding: 14px; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; text-align: center; color: #0369a1; font-size: 16px; font-weight: 600; line-height: 1.7;"></div>

        <?php if ( 'yes' === $atts['credit'] ) : ?>
            <div style="margin-top: 16px; padding-top: 10px; border-top: 1px solid #f1f5f9; text-align: left; font-size: 12px; color: #64748b;">
                أداة <a href="https://hasbati.com/date-converter/" target="_blank" rel="noopener" style="color: #0284c7; text-decoration: none; font-weight: 600;">تحويل التاريخ</a> - حاسبتي
            </div>
        <?php endif; ?>
    </div>

    <script>
    (function() {
        const container = document.getElementById('<?php echo esc_js( $uid ); ?>');
        if (!container) return;

        const modeEl  = container.querySelector('.hasbati-dc-mode');
        const dayEl   = container.querySelector('.hasbati-dc-day');
        const monthEl = container.querySelector('.hasbati-dc-month');
        const yearEl  = container.querySelector('.hasbati-dc-year');
        const btnEl   = container.querySelector('.hasbati-dc-btn');
        const resEl   = container.querySelector('.hasbati-dc-result');

        // دالة استخراج أجزاء التاريخ الهجري من كائن تاريخ ميلادي عبر تقويم أم القرى
        function getHijriParts(dateObj) {
            const fmt = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
                day: 'numeric', month: 'numeric', year: 'numeric'
            });
            const parts = fmt.formatToParts(dateObj);
            let d = 1, m = 1, y = 1448;
            parts.forEach(p => {
                if (p.type === 'day') d = parseInt(p.value, 10);
                if (p.type === 'month') m = parseInt(p.value, 10);
                if (p.type === 'year') y = parseInt(p.value.replace(/[^0-9]/g, ''), 10);
            });
            return { d, m, y };
        }

        // تبديل القيم الافتراضية عند تغيير نوع التحويل
        modeEl.addEventListener('change', function() {
            const now = new Date();
            if (this.value === 'h2g') {
                const h = getHijriParts(now);
                dayEl.value = h.d;
                monthEl.value = h.m;
                yearEl.value = h.y;
            } else {
                dayEl.value = now.getDate();
                monthEl.value = now.getMonth() + 1;
                yearEl.value = now.getFullYear();
            }
            resEl.style.display = 'none';
        });

        btnEl.addEventListener('click', function() {
            const mode = modeEl.value;
            const d = parseInt(dayEl.value, 10);
            const m = parseInt(monthEl.value, 10);
            const y = parseInt(yearEl.value, 10);

            if (isNaN(d) || isNaN(m) || isNaN(y) || d < 1 || d > 31 || m < 1 || m > 12) {
                resEl.style.display = 'block';
                resEl.innerHTML = 'يرجى إدخال تاريخ صحيح.';
                return;
            }

            if (mode === 'g2h') {
                // تحويل من ميلادي إلى هجري
                const gDate = new Date(y, m - 1, d, 12, 0, 0);
                const hijriFull = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
                    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
                }).format(gDate);
                const hijriNum = getHijriParts(gDate);

                resEl.style.display = 'block';
                resEl.innerHTML = 'التاريخ الهجري الموافق:<br><span style="font-size:18px; color:#0f172a;">' + hijriFull + '</span><br><span style="font-size:14px; color:#475569;">(' + hijriNum.y + '/' + hijriNum.m + '/' + hijriNum.d + ' هـ)</span>';
            } else {
                // تحويل من هجري إلى ميلادي عبر البحث التقريبي الدقيق في تقويم أم القرى
                const approxGregYear = Math.floor(y * 0.970224 + 621.57);
                let testDate = new Date(approxGregYear, m - 1, d, 12, 0, 0);
                let found = false;

                // ضبط سريع للوصول لليوم المطابق تماماً
                for (let i = -400; i <= 400; i++) {
                    const checkDate = new Date(testDate.getTime() + (i * 86400000));
                    const hp = getHijriParts(checkDate);
                    if (hp.y === y && hp.m === m && hp.d === d) {
                        testDate = checkDate;
                        found = true;
                        break;
                    }
                }

                if (found) {
                    const gregFull = new Intl.DateTimeFormat('ar-EG', {
                        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
                    }).format(testDate);
                    const gy = testDate.getFullYear();
                    const gm = testDate.getMonth() + 1;
                    const gd = testDate.getDate();

                    resEl.style.display = 'block';
                    resEl.innerHTML = 'التاريخ الميلادي الموافق:<br><span style="font-size:18px; color:#0f172a;">' + gregFull + '</span><br><span style="font-size:14px; color:#475569;">(' + gy + '/' + gm + '/' + gd + ' م)</span>';
                } else {
                    resEl.style.display = 'block';
                    resEl.innerHTML = 'تأكد من صحة التاريخ الهجري المدخل.';
                }
            }
        });
    })();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode( 'hasbati_date_converter', 'hasbati_dc_shortcode_render' );