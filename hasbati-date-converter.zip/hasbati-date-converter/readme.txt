=== Hasbati Hijri Date Converter ===
Contributors: hasbati
Tags: hijri date, date converter, umm al-qura, islamic calendar, arabic calendar
Requires at least: 5.2
Tested up to: 7.1
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight and accurate Hijri to Gregorian and Gregorian to Hijri date converter widget based on the official Umm al-Qura calendar.

== Description ==

**Hasbati Hijri Date Converter** allows WordPress site owners and publishers to easily embed an interactive, accurate date conversion tool between the Islamic Hijri calendar (Umm al-Qura system) and the Gregorian calendar inside any post, page, or widget area using a simple shortcode.

All calculations run locally in the browser using standard modern JavaScript APIs without slowing down your website. This plugin is developed by the team at [Hasbati](https://hasbati.com/) and is powered by the official [Hijri and Gregorian Date Converter](https://hasbati.com/date-converter/) methodology.

### Key Features:
* **Dual Conversion:** Convert dates seamlessly from Gregorian to Hijri and from Hijri to Gregorian.
* **Official Umm al-Qura Calendar:** Accurate calculation of Islamic days, months, and years along with the exact weekday name.
* **Ultra-Fast Performance:** Runs purely on native browser JavaScript with zero external library dependencies.
* **RTL & Arabic Interface Ready:** Designed with a clean, responsive RTL Arabic user interface that fits mobile and desktop screens.

### Shortcode Usage:
Add the following shortcode to any post, page, or widget:
`[hasbati_date_converter]`

To enable the optional attribution footer link:
`[hasbati_date_converter credit="yes"]`

== Installation ==

1. Upload the `hasbati-date-converter` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to 'Settings -> محول التاريخ (حاسبتي)' to copy the shortcode and configure options.

== Frequently Asked Questions ==

= Does this plugin affect website speed? =
No, the plugin is extremely lightweight and only outputs inline HTML and native JavaScript on pages where the shortcode is actively used.

= Which calendar system is used for conversion? =
The calculator relies on the official Umm al-Qura calendar algorithm, matching the core engine used on the [Hasbati Date Converter](https://hasbati.com/date-converter/) web application.

== Changelog ==

= 1.0.0 =
* Initial release of the Hasbati Hijri Date Converter plugin.